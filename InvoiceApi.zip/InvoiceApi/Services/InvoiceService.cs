using InvoiceApi.Models;

namespace InvoiceApi.Services;

// Servicio estático para manejar facturas en memoria
public static class InvoiceService
{
    // Lista estática de facturas
    private static readonly List<Invoice> Invoices = new();

    // Agrega una factura a la lista
    public static void AddInvoice(Invoice invoice)
    {
        Invoices.Add(invoice);
    }

    // Obtiene las facturas de un cliente ordenadas por fecha
    public static IEnumerable<Invoice> GetInvoicesByCustomer(int customerId)
    {
        return Invoices
            .Where(i => i.CustomerId == customerId)
            .OrderBy(i => i.Date);
    }
}
