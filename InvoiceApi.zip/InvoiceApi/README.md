# Proyecto: API REST de Facturas (Invoice API)

## Descripción
Esta es una pequeña API REST desarrollada en .NET 8 que permite registrar y consultar facturas. Los datos se almacenan en memoria usando una lista estática. Se implementa AutoMapper y DTOs para separar los modelos de entrada y salida.

## Requisitos
- .NET SDK 6.0 o superior
- Visual Studio Code (o cualquier editor)
- Extensión C# para VS Code
- AutoMapper.Extensions.Microsoft.DependencyInjection (ya incluido)

## Estructura del Proyecto

- `Models/Invoice.cs`: Modelo principal
- `DTOs/InvoiceCreateDto.cs`, `InvoiceReadDto.cs`: DTOs para entrada/salida
- `Services/InvoiceService.cs`: Simula almacenamiento en memoria
- `Mapping/MappingProfile.cs`: Configuración de AutoMapper
- `Controllers/InvoicesController.cs`: API con endpoints

## Cómo ejecutar

1. Abrir terminal y ubicarse en la carpeta del proyecto.
2. Ejecutar:

dotnet restore
dotnet run
