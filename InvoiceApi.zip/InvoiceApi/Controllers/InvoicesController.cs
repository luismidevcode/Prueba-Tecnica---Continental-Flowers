using AutoMapper;
using InvoiceApi.DTOs;
using InvoiceApi.Models;
using InvoiceApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace InvoiceApi.Controllers;

// Controlador para manejar endpoints de facturas
[ApiController]
[Route("api/[controller]")]
public class InvoicesController : ControllerBase
{
    private readonly IMapper _mapper;

    // Constructor con inyección de dependencias
    public InvoicesController(IMapper mapper)
    {
        _mapper = mapper;
    }

    // Endpoint para crear una nueva factura
    [HttpPost]
    public IActionResult CreateInvoice([FromBody] InvoiceCreateDto invoiceDto)
    {
        // Validación del total
        if (invoiceDto.Total < 0)
            return BadRequest("Total debe ser mayor a cero.");

        // Validación de la fecha
        if (invoiceDto.Date > DateTime.UtcNow)
            return BadRequest("La fecha no puede ser mayor a hoy.");

        // Mapeo y guardado de la factura
        var invoice = _mapper.Map<Invoice>(invoiceDto);
        InvoiceService.AddInvoice(invoice);

        // Retorna respuesta de creación
        return CreatedAtAction(nameof(GetInvoicesByCustomer), new { customerId = invoice.CustomerId }, null);
    }

    // Endpoint para obtener facturas por cliente
    [HttpGet("{customerId}")]
    public ActionResult<IEnumerable<InvoiceReadDto>> GetInvoicesByCustomer(int customerId)
    {
        // Obtiene y mapea las facturas
        var invoices = InvoiceService.GetInvoicesByCustomer(customerId);
        var result = _mapper.Map<IEnumerable<InvoiceReadDto>>(invoices);
        return Ok(result);
    }
}
