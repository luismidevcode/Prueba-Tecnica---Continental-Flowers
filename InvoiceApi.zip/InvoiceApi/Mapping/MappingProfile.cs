using AutoMapper;
using InvoiceApi.DTOs;
using InvoiceApi.Models;

namespace InvoiceApi.Mapping;

// Perfil de AutoMapper para mapear entre DTOs y modelos
public class MappingProfile : Profile
{
    public MappingProfile()
    {
        // Mapeo de DTO de creación a modelo
        CreateMap<InvoiceCreateDto, Invoice>();
        // Mapeo de modelo a DTO de lectura
        CreateMap<Invoice, InvoiceReadDto>();
    }
}
