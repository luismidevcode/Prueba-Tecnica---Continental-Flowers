namespace InvoiceApi.DTOs;

// DTO para la creación de facturas
public class InvoiceCreateDto
{
    public int InvoiceId { get; set; }
    public int CustomerId { get; set; }
    public DateTime Date { get; set; }
    public decimal Total { get; set; }
}