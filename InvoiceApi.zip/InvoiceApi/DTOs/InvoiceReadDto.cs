namespace InvoiceApi.DTOs;

// DTO para la lectura de facturas
public class InvoiceReadDto
{
    // Identificador de la factura
    public int InvoiceId { get; set; }
    // Fecha de la factura
    public DateTime Date { get; set; }
    // Total de la factura
    public decimal Total { get; set; }
}